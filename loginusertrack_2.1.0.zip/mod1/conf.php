<?php
// DO NOT REMOVE OR CHANGE THESE 2 LINES:
$MCONF['name'] = 'web_txloginusertrackM1';
$MCONF['script'] = '_DISPATCH';
$MCONF['access'] = 'user,group';
$MLANG['default']['tabs_images']['tab'] = 'moduleicon.gif';
$MLANG['default']['ll_ref'] = 'LLL:EXT:loginusertrack/mod1/locallang_mod.php';